# Nhập mật khẩu mới lần 1
mat_khau_moi = input("Bạn hãy nhập mật khẩu mới: ")

# Nhập xác nhận mật khẩu lần 2
xac_nhan_mat_khau = input("Bạn hãy nhập xác nhận mật khẩu mới lần 2: ")

# Tiến hành kiểm tra: So sánh hai biến (mat_khau_moi và xac_nhan_mat_khau)
if mat_khau_moi == xac_nhan_mat_khau: # Lỗi chính tả đã được sửa ở đây
    # Nếu hai chuỗi (mật khẩu) giống nhau
    print("\nMật khẩu đã được đổi thành công 🎉")
else:
    # Nếu hai chuỗi (mật khẩu) không giống nhau
    print("\nMật khẩu không giống nhau rồi 🚨")