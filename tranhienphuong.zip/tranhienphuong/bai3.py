try:
    # Nhập giá trị nhiệt độ N
    N = int(input("Nhập giá trị nhiệt độ (độ C): "))

    print(f"\nNhiệt độ đã nhập là: {N}°C")

    # Kiểm tra điều kiện thời tiết
    if N > 30:
        # Nếu N lớn hơn 30
        print("Tình hình thời tiết: **Trời đang nóng** 🔥")
    elif N < 20:
        # Nếu N không lớn hơn 30 VÀ nhỏ hơn 20
        print("Tình hình thời tiết: **Trời đang lạnh** 🥶")
    else:
        # Nếu N không rơi vào 2 trường hợp trên (tức là 20 <= N <= 30)
        print("Tình hình thời tiết: **Thời tiết dễ chịu** 😊")

except ValueError:
    print("Lỗi: Vui lòng nhập một số nguyên hợp lệ cho nhiệt độ.")