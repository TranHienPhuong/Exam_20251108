def tinh_tien_taxi(km):
    """
    Tính tổng tiền taxi dựa trên quãng đường (km) đã đi.
    """
    if km <= 0:
        return 0

    tong_tien = 0

    # Trường hợp 1: Quãng đường đi từ 1km trở xuống (0 < km <= 1)
    if km <= 1:
        tong_tien = km * 7000
        return round(tong_tien)  # Làm tròn số tiền

    # Trường hợp 2: Quãng đường trên 1km đến 5km (1 < km <= 5)
    elif km <= 5:
        # 1 km đầu: 7000đ
        tong_tien += 7000
        # Các km còn lại (từ km thứ 2 đến km thứ 5): (km - 1) * 6500đ
        km_con_lai = km - 1
        tong_tien += km_con_lai * 6500
        return round(tong_tien)

    # Trường hợp 3: Quãng đường trên 5km (km > 5)
    else:
        # 1 km đầu: 7000đ
        tong_tien += 7000

        # Từ km thứ 2 đến km thứ 5 (4 km tiếp theo): 4 * 6500đ
        tong_tien += 4 * 6500  # 4 * 6500 = 26000

        # Các km còn lại (trên 5km): (km - 5) * 6000đ
        km_sau_5 = km - 5
        tong_tien += km_sau_5 * 6000
        return round(tong_tien)


# --- Chương trình chính ---
try:
    # Nhập quãng đường, cho phép nhập số thực
    km_da_di = float(input("Nhập số Km đã đi của xe taxi: "))

    if km_da_di < 0:
        print("Quãng đường không thể là số âm.")
    else:
        so_tien = tinh_tien_taxi(km_da_di)
        # Sử dụng định dạng tiền tệ cho dễ đọc
        so_tien_format = "{:,.0f}".format(so_tien).replace(",", ".")
        print(f"\nQuãng đường đã đi: {km_da_di} Km")
        print(f"Tổng tiền phải trả là: **{so_tien_format}đ**")

except ValueError:
    print("Lỗi: Vui lòng nhập một số hợp lệ cho quãng đường (Km).")