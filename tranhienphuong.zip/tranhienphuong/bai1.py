# Nhập 3 số nguyên X1, X2, X3 từ người dùng
try:
    X1 = int(input("Nhập số nguyên X1: "))
    X2 = int(input("Nhập số nguyên X2: "))
    X3 = int(input("Nhập số nguyên X3: "))

    # Sử dụng hàm min() để tìm số nhỏ nhất
    so_nho_nhat = min(X1, X2, X3)

    # In kết quả
    print(f"\nBa số đã nhập là: {X1}, {X2}, {X3}")
    print(f"Số nhỏ nhất trong 3 số là: **{so_nho_nhat}**")

except ValueError:
    print("Lỗi: Vui lòng chỉ nhập các số nguyên hợp lệ.")
