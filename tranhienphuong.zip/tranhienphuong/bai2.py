try:
    N = int(input("Nhập năm dương lịch N: "))

    # Điều kiện 1: (N % 4 == 0) và (N % 100 == 0)
    dieu_kien_1 = (N % 4 == 0) and (N % 100 == 0)

    # Điều kiện 2: N % 400 == 0
    dieu_kien_2 = (N % 400 == 0)

    # Nhuận nếu thỏa mãn ĐK 1 HOẶC ĐK 2
    if dieu_kien_1 or dieu_kien_2:
        print(f"Năm {N} là NĂM NHUẬN (theo quy tắc đã cho).")
    else:
        print(f"Năm {N} KHÔNG phải là năm nhuận (theo quy tắc đã cho).")

except ValueError:
    print("Lỗi: Vui lòng nhập một số nguyên hợp lệ cho năm.")